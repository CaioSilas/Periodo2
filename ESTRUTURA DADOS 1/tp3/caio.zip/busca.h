#include <stdio.h>
#include <stdlib.h>
#include <string.h>

# ifndef busca_h
# define busca_h

typedef double Tchave;

typedef struct
{
    double x;
    double volumeTotal;
    Tchave altura;
    double n;
}TEscultura;

TEscultura *TEsculturaInicializa(int qnt);

 /* encontra o í ndice da chave x no dicion á rio entre esq e dir */
double TEscultura_Binaria ( TEscultura *t , double esq ,double dir);

void desaloca(TEscultura **t);

#endif