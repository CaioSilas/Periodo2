//Caio silas - Matricula : 21.1.4111
//Turmas 21-22


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ordenacao.h"


int main(){
    int qnt;
    scanf("%d",&qnt);
    // printf("%d",qnt);
    //lendo do arquivo a quantidade de upa para fazer o alocamento
    // FILE* arq = fopen(argv[1],"r");
    // if(arq == NULL){
    //     printf("Nao foi possivel abrir o arquivo!!\n");
    //     exit(EXIT_FAILURE);
    // }
    // fscanf(arq,"%d",&qnt);
    // fclose(arq);
    Tupa *upa = NULL;
    //alocando a struct
    alocaUpa(&upa,qnt);
    //preenchendo a struct
    Completaupa(&upa,qnt);
    //ordenando a struct
    ordena(&upa,qnt);
    printupa(&upa,qnt);

    free(upa);
    return 0;
}